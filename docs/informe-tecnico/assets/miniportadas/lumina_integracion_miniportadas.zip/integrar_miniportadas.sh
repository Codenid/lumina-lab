#!/usr/bin/env bash
set -euo pipefail
ROOT="$(git rev-parse --show-toplevel)"
cd "$ROOT"
python3 - <<'PYINNER'
from pathlib import Path
import shutil,re
root=Path.cwd()
assets=root/'docs/informe-tecnico/assets/miniportadas'
assets.mkdir(parents=True,exist_ok=True)
files=sorted((root/'lumina_miniportadas').glob('*.png'))
assert len(files)==12, f'Se esperaban 12 PNG, se encontraron {len(files)}'
for f in files: shutil.copy2(f,assets/f.name)
report=root/'docs/informe-tecnico/informe/informe-tecnico-implementacion-gcp.md'
s=report.read_text(encoding='utf-8')
count=0
for f in files:
    old=f'../assets/miniportadas/{f.stem}.svg'
    new=f'../assets/miniportadas/{f.name}'
    assert s.count(old)==1, f'Referencia no única: {old}'
    s=s.replace(old,new)
    count+=1
report.write_text(s,encoding='utf-8')
assert count==12
print('12 imágenes instaladas y 12 referencias actualizadas.')
PYINNER
git add docs/informe-tecnico/assets/miniportadas/*.png docs/informe-tecnico/informe/informe-tecnico-implementacion-gcp.md
git commit -m "docs: integrar 12 miniportadas ilustradas en el informe"
git push origin HEAD
